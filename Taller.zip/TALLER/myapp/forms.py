from django import forms


class Formulario(forms.Form):
	nombre = forms.CharField(label='Ingrese Nombre',widget=forms.TextInput(
		attrs={
			'class':'form-control',
            'placeholder':'Nombre'
		}))

	apellido = forms.CharField(label='Ingrese Apellido',widget=forms.TextInput(
		attrs={
			'class':'form-control',
            'placeholder':'Apellido'
		}))

	edad = forms.IntegerField(label='Ingrese Edad',widget=forms.TextInput(
		attrs={
			'class':'form-control',
			'type':'number',
            'placeholder': 'Edad'
		}))

	password = forms.CharField(label='Ingrese Password',widget=forms.TextInput(
		attrs={
			'class':'form-control',
			'type':'password',
            'placeholder':'Contraseña'
		}))	
	email = forms.CharField(label='Ingrese Email',widget=forms.TextInput(
		attrs={
			'class':'form-control',
			'type':'mail',
            'placeholder':'Mail'
		}))	