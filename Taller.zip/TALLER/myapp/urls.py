from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.jumbotron, name = "jumbotron"),
    path('formulario',views.formulario, name = 'formulario'),
    path('resultados',views.resultados, name = "resultados"),
    path('desechos', views.desechos, name= "desechos"),
    path('NovorapidReciclar', views.NovorapidReciclar, name="NovorapidReciclar"),
    path('NovorapidReutilizar', views.NovorapidReutilizar, name="NovorapidReutilizar"),
    path('FreestyleReciclar', views.FreestyleReciclar, name="FreestyleReciclar"),
    path('FreestyleReutilizar', views.FreestyleReutilizar, name="FreestyleReutilizar"),
    path('SensorReciclar', views.SensorReciclar, name="SensorReciclar"),
    path('SensorReutilizar', views.SensorReutilizar, name="SensorReutilizar"),
    path('ReservoirReciclar', views.ReservoirReciclar, name="ReservoirReciclar"),
    path('ReservoirReutilizar', views.ReservoirReutilizar, name="ReservoirReutilizar"),
    path('QuickReciclar', views.QuickReciclar, name="QuickReciclar"),
    path('QuickReutilizar', views.QuickReutilizar, name="QuickReutilizar")
]
