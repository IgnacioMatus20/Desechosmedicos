from django.shortcuts import render
from .forms import *

# Create your views here.
def formulario(request):
	form = Formulario()
	return render(request, 'myapp/formulario.html',{'form':form})

def jumbotron(request):
    return render(request,'myapp/jumbotron.html')

def desechos(request):
	return render(request, 'myapp/desechos.html')

def NovorapidReciclar(request):
	return render(request, 'myapp/NovorapidReciclar.html')

def NovorapidReutilizar(request):
	return render(request, 'myapp/NovorapidReutilizar.html')

def FreestyleReciclar(request):
	return render(request, 'myapp/FreestyleReciclar.html')

def FreestyleReutilizar(request):
	return render(request, 'myapp/FreestyleReutilizar.html')

def SensorReciclar(request):
	return render(request, 'myapp/SensorReciclar.html')

def SensorReutilizar(request):
	return render(request, 'myapp/SensorReutilizar.html')

def ReservoirReciclar(request):
	return render(request, 'myapp/ReservoirReciclar.html')

def ReservoirReutilizar(request):
	return render(request, 'myapp/ReservoirReutilizar.html')

def QuickReciclar(request):
	return render(request, 'myapp/QuickReciclar.html')

def QuickReutilizar(request):
	return render(request, 'myapp/QuickReutilizar.html')
	

def resultados(request):
	nombre = request.POST['nombre']
	apellido = request.POST['apellido']
	edad = request.POST['edad']
	password = request.POST['password']
	email = request.POST['email']
	contexto = {'nombre':nombre,
				'edad':edad,
				'apellido':apellido,
				'password':password,
				'email':email
				}
	if(edad == '42'):
		contexto['respuesta'] = "la respuesta del universo!!!!!"
	
	return render(request, 'myapp/resultados.html',contexto)
