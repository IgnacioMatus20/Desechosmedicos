from myapp.models import Proyecto


proyecto= Proyecto(descripcion="Pasar el semestre online",
	cliente="EstudiantesChilenos", fecha_limite="2020-08-31")

#Desafios
from myapp.models import Desafio

desafio1= Desafio(titulo="Desafio1", descripcion="eliminar electro de la malla", 
	fecha="2020-08-15")

desafio2= Desafio(titulo="Desafio2", descripcion="Obvio, apruebo convencion constituyente",
	fecha="2020-10-25")

#grupo
from myapp.models import Grupo

grupo= Grupo(nombre="anonymous", proyecto=proyecto)

#Alumnos
from myapp.models import Estudiante

alumno1= Estudiante(nombre= "Zoila Cerda", correo="zoila.cerda@ug.uchile.cl",
	numero=1, grupo=grupo)

alumno2= Estudiante(nombre= "Aquiles Castro", correo="cortacoquitos@gmail.com",
	numero=2, grupo=grupo)

alumno3= Estudiante(nombre= "Luis Pay", correo="Lusho.p@gmail.com",
	numero=3, grupo=grupo)

alumno4= Estudiante(nombre= "Armando Casas", correo="bobconstructor@gmail.com",
	numero=4, grupo=grupo)

#Entrega

from myapp.models import DesafiosEstudiantes

DesafiosEstudiantes1= DesafiosEstudiantes(estudiante=alumno1, desafio=desafio1,
	fueEntregado="False")

DesafiosEstudiantes1= DesafiosEstudiantes(estudiante=alumno1, desafio=desafio2,
	fueEntregado="False")

DesafiosEstudiantes2= DesafiosEstudiantes(estudiante=alumno2, desafio=desafio1,
	fueEntregado="True")

DesafiosEstudiantes2= DesafiosEstudiantes(estudiante=alumno2, desafio=desafio2,
	fueEntregado="True")

DesafiosEstudiantes3= DesafiosEstudiantes(estudiante=alumno3, desafio=desafio1,
	fueEntregado="False")

DesafiosEstudiantes3= DesafiosEstudiantes(estudiante=alumno3, desafio=desafio2,
	fueEntregado="False")

DesafiosEstudiantes4= DesafiosEstudiantes(estudiante=alumno4, desafio=desafio1,
	fueEntregado="False")

DesafiosEstudiantes4= DesafiosEstudiantes(estudiante=alumno4, desafio=desafio2,
	fueEntregado="False")

proyecto.save()
desafio1.save()
desafio2.save()
grupo.save()
alumno1.save()
alumno2.save()
alumno3.save()
alumno4.save()
DesafiosEstudiantes1.save()
DesafiosEstudiantes2.save()
DesafiosEstudiantes3.save()
DesafiosEstudiantes4.save()

